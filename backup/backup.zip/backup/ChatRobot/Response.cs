﻿namespace ChatRobot
{
    public class Response
    {
        public string Question { set; get; }
        public string Answer { set; get; }
    }
}
