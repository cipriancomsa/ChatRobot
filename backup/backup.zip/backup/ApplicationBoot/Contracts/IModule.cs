﻿namespace ApplicationBoot.Contracts
{
    public interface IModule
    {
        void Init();
    }
}