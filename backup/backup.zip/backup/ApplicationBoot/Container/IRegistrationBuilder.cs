﻿namespace ApplicationBoot.Container
{
    public interface IRegistrationBuilder
    {
        void Register();
    }
}